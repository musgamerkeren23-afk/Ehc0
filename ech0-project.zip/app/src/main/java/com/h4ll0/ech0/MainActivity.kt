package com.h4ll0.ech0

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Red = Color(0xFFE0262E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("ech0", MODE_PRIVATE)
        Api.saver = { s ->
            val e = p.edit()
            if (s == null) e.clear() else {
                e.putString("a", s.access).putString("r", s.refresh).putString("u", s.uid).putString("n", s.name)
            }
            e.apply()
        }
        val a = p.getString("a", null)
        if (a != null) Api.sess = Session(a, p.getString("r", "")!!, p.getString("u", "")!!, p.getString("n", "user")!!)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var logged by remember { mutableStateOf(Api.sess != null) }
    if (!logged) Login { logged = true } else Chat { Api.logout(); logged = false }
}

@Composable
fun Login(onOk: () -> Unit) {
    var u by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun go(sign: Boolean) {
        if (u.trim().length < 3 || pw.length < 6) { err = "Username min 3 huruf, password min 6"; return }
        busy = true; err = ""
        scope.launch {
            val r = withContext(Dispatchers.IO) { Api.login(u, pw, sign) }
            busy = false
            r.onSuccess { onOk() }.onFailure { err = it.message ?: "Gagal" }
        }
    }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("Ech0", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(u, { u = it }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        if (err.isNotEmpty()) Text(err, color = Color(0xFFFF7B7B), modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button({ go(false) }, Modifier.fillMaxWidth(), enabled = !busy) { Text(if (busy) "Tunggu..." else "Masuk") }
        OutlinedButton({ go(true) }, Modifier.fillMaxWidth(), enabled = !busy) { Text("Daftar") }
    }
}

private fun hhmm(s: String) = runCatching {
    java.time.OffsetDateTime.parse(s).atZoneSameInstant(java.time.ZoneId.systemDefault())
        .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
}.getOrDefault("")

@Composable
fun Chat(onOut: () -> Unit) {
    val c = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var servers by remember { mutableStateOf<List<Server>>(emptyList()) }
    var srv by remember { mutableStateOf<Server?>(null) }
    var chs by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
    var cur by remember { mutableStateOf<Pair<Long, String>?>(null) }
    var msgs by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var txt by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val list = rememberLazyListState()
    fun toast(t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()

    suspend fun loadServers(select: Long? = null) {
        servers = withContext(Dispatchers.IO) { Api.servers() }
        srv = servers.firstOrNull { it.id == (select ?: srv?.id) } ?: servers.firstOrNull()
    }

    LaunchedEffect(Unit) { loadServers(); if (servers.isEmpty()) drawer.open() }
    LaunchedEffect(srv?.id) {
        cur = null; msgs = emptyList()
        val s = srv
        if (s == null) { chs = emptyList(); return@LaunchedEffect }
        chs = withContext(Dispatchers.IO) { Api.channels(s.id) }
        cur = chs.firstOrNull()
    }
    LaunchedEffect(cur) {
        msgs = emptyList()
        val ch = cur ?: return@LaunchedEffect
        while (true) {
            val r = withContext(Dispatchers.IO) { Api.messages(ch.first) }
            if (r != null && r.map { it.id } != msgs.map { it.id }) msgs = r
            delay(2000)
        }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.lastIndex) }

    fun send() {
        val v = txt.trim(); val ch = cur ?: return
        if (v.isEmpty()) return
        txt = ""
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Api.send(ch.first, v) }
            if (!ok) toast("Gagal kirim")
            else withContext(Dispatchers.IO) { Api.messages(ch.first) }?.let { msgs = it }
        }
    }

    if (dlg.isNotEmpty()) AlertDialog(
        onDismissRequest = { dlg = ""; input = "" },
        title = { Text(when (dlg) { "create" -> "Buat server"; "join" -> "Gabung server"; else -> "Buat channel" }) },
        text = {
            OutlinedTextField(input, { input = it }, singleLine = true,
                label = { Text(when (dlg) { "join" -> "Kode undangan"; "create" -> "Nama server"; else -> "Nama channel" }) })
        },
        confirmButton = {
            TextButton({
                val v = input.trim(); val d = dlg; val sid = srv?.id
                if (v.isEmpty()) return@TextButton
                dlg = ""; input = ""
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        when (d) {
                            "create" -> Api.createServer(v)
                            "join" -> Api.joinServer(v)
                            else -> Api.createChannel(sid ?: 0L, v)
                        }
                    }
                    if (r.isFailure) { toast(r.exceptionOrNull()?.message ?: "Gagal"); return@launch }
                    val id = r.getOrNull()
                    if (d == "channel" && sid != null) {
                        chs = withContext(Dispatchers.IO) { Api.channels(sid) }
                        cur = chs.firstOrNull { it.first == id } ?: cur
                    } else loadServers(id)
                    drawer.close()
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton({ dlg = ""; input = "" }) { Text("Batal") } }
    )

    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        ModalDrawerSheet {
            Text("Ech0", Modifier.padding(20.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Red)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                servers.forEach { s ->
                    if (s.id == srv?.id) Button({}) { Text(s.name) } else OutlinedButton({ srv = s }) { Text(s.name) }
                }
            }
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ dlg = "create" }) { Text("+ Buat") }
                OutlinedButton({ dlg = "join" }) { Text("Gabung") }
            }
            srv?.let { s ->
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                Text("Kode undangan: ${s.code} (tap salin)", color = Color.Gray, fontSize = 13.sp,
                    modifier = Modifier.clickable { clip.setText(AnnotatedString(s.code)); toast("Kode disalin") }
                        .padding(horizontal = 20.dp, vertical = 8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    chs.forEach { ch ->
                        NavigationDrawerItem(label = { Text("# ${ch.second}") }, selected = ch == cur,
                            onClick = { cur = ch; scope.launch { drawer.close() } }, modifier = Modifier.padding(horizontal = 8.dp))
                    }
                    if (s.owner == Api.sess?.uid) TextButton({ dlg = "channel" }, Modifier.padding(horizontal = 8.dp)) { Text("+ Channel") }
                }
            }
            if (srv == null) Spacer(Modifier.weight(1f))
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Api.sess?.name ?: "", Modifier.weight(1f))
                TextButton(onOut) { Text("Keluar") }
            }
        }
    }) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ scope.launch { drawer.open() } }) { Text("☰", fontSize = 22.sp) }
                Text("${srv?.name ?: "Ech0"}  #${cur?.second ?: "..."}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            HorizontalDivider()
            if (srv == null) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Belum ada server.\nBuka ☰ lalu Buat server atau Gabung pakai kode undangan.", textAlign = TextAlign.Center, color = Color.Gray)
                }
            } else LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list) {
                items(msgs, key = { it.id }) { m ->
                    Row(Modifier.padding(vertical = 6.dp)) {
                        Box(Modifier.size(36.dp).clip(CircleShape).background(Red), contentAlignment = Alignment.Center) {
                            Text(m.user.take(1).uppercase(), fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(m.user, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(6.dp))
                                Text(hhmm(m.time), fontSize = 11.sp, color = Color.Gray)
                            }
                            Text(m.text)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), enabled = cur != null,
                    placeholder = { Text("Ketik pesan...") }, maxLines = 4)
                Spacer(Modifier.width(8.dp))
                Button({ send() }, enabled = cur != null) { Text("Kirim") }
            }
        }
    }
}
