package com.h4ll0.ech0

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Config {
    const val SB_URL = "__SUPABASE_URL__"
    const val SB_KEY = "__SUPABASE_KEY__"
}

class Session(val access: String, val refresh: String, val uid: String, val name: String)
data class Server(val id: Long, val name: String, val code: String, val owner: String)
data class Msg(val id: Long, val user: String, val text: String, val time: String)

object Api {
    var sess: Session? = null
    var saver: (Session?) -> Unit = {}

    private fun raw(method: String, path: String, body: String?, token: String,
                    extra: Map<String, String> = emptyMap()): Pair<Int, String> {
        var c: HttpURLConnection? = null
        try {
            c = URL(Config.SB_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.setRequestProperty("apikey", Config.SB_KEY)
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "application/json")
            extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
            val code = c.responseCode
            val s = if (code in 200..299) c.inputStream else c.errorStream
            return code to (s?.bufferedReader()?.use { it.readText() } ?: "")
        } catch (e: Exception) {
            return -1 to "Koneksi gagal (cek internet / URL Supabase)"
        } finally { c?.disconnect() }
    }

    private fun parse(t: String, code: Int): Result<Session> {
        if (code == -1) return Result.failure(Exception(t))
        val j = try { JSONObject(t) } catch (e: Exception) { return Result.failure(Exception("Respon tidak valid ($code)")) }
        if (code !in 200..299) {
            val m = j.optString("msg", j.optString("error_description", j.optString("message", "Gagal ($code)")))
            return Result.failure(Exception(m))
        }
        val at = j.optString("access_token")
        if (at.isEmpty()) return Result.failure(Exception("Matikan 'Confirm email' di Supabase, lalu coba lagi"))
        val u = j.getJSONObject("user")
        val name = u.optJSONObject("user_metadata")?.optString("username").orEmpty().ifEmpty { "user" }
        return Result.success(Session(at, j.getString("refresh_token"), u.getString("id"), name))
    }

    private fun email(u: String) = u.trim().lowercase().filter { it.isLetterOrDigit() || it == '_' } + "@ech0-app.com"

    fun login(user: String, pw: String, signup: Boolean): Result<Session> {
        val e = email(user)
        val (code, t) = if (signup) {
            val b = JSONObject().put("email", e).put("password", pw)
                .put("data", JSONObject().put("username", user.trim())).toString()
            raw("POST", "/auth/v1/signup", b, Config.SB_KEY)
        } else {
            val b = JSONObject().put("email", e).put("password", pw).toString()
            raw("POST", "/auth/v1/token?grant_type=password", b, Config.SB_KEY)
        }
        return parse(t, code).onSuccess { sess = it; saver(it) }
    }

    private fun refresh(): Boolean {
        val s = sess ?: return false
        val b = JSONObject().put("refresh_token", s.refresh).toString()
        val (code, t) = raw("POST", "/auth/v1/token?grant_type=refresh_token", b, Config.SB_KEY)
        val r = parse(t, code).getOrNull() ?: return false
        sess = r; saver(r)
        return true
    }

    fun logout() { sess = null; saver(null) }

    private fun authed(method: String, path: String, body: String? = null,
                       extra: Map<String, String> = emptyMap()): Pair<Int, String> {
        val s = sess ?: return -1 to "belum login"
        var r = raw(method, path, body, s.access, extra)
        if (r.first == 401 && refresh()) r = raw(method, path, body, sess!!.access, extra)
        return r
    }

    fun servers(): List<Server> = runCatching {
        val (c, t) = authed("GET", "/rest/v1/servers?select=id,name,invite_code,owner_id&order=id")
        if (c !in 200..299) return emptyList()
        val a = JSONArray(t)
        List(a.length()) { i -> a.getJSONObject(i).let { Server(it.getLong("id"), it.getString("name"), it.getString("invite_code"), it.getString("owner_id")) } }
    }.getOrDefault(emptyList())

    fun channels(serverId: Long): List<Pair<Long, String>> = runCatching {
        val (c, t) = authed("GET", "/rest/v1/channels?select=id,name&server_id=eq.$serverId&order=id")
        if (c !in 200..299) return emptyList()
        val a = JSONArray(t)
        List(a.length()) { i -> a.getJSONObject(i).let { it.getLong("id") to it.getString("name") } }
    }.getOrDefault(emptyList())

    private fun rpc(name: String, body: JSONObject): Result<JSONObject> {
        val (c, t) = authed("POST", "/rest/v1/rpc/$name", body.toString())
        return try {
            val j = JSONObject(t)
            if (c in 200..299) Result.success(j) else Result.failure(Exception(j.optString("message", "Gagal ($c)")))
        } catch (e: Exception) { Result.failure(Exception(if (c == -1) t else "Respon tidak valid ($c)")) }
    }
    fun createServer(n: String) = rpc("create_server", JSONObject().put("p_name", n)).mapCatching { it.getLong("id") }
    fun joinServer(code: String) = rpc("join_server", JSONObject().put("p_code", code)).mapCatching { it.getLong("id") }
    fun createChannel(sid: Long, n: String) = rpc("create_channel", JSONObject().put("p_server", sid).put("p_name", n)).mapCatching { it.getLong("id") }

    fun messages(ch: Long): List<Msg>? = runCatching {
        val (c, t) = authed("GET", "/rest/v1/messages?select=id,username,content,created_at&channel_id=eq.$ch&order=created_at.desc&limit=100")
        if (c !in 200..299) return null
        val a = JSONArray(t)
        List(a.length()) { i ->
            a.getJSONObject(i).let { Msg(it.getLong("id"), it.getString("username"), it.getString("content"), it.getString("created_at")) }
        }.reversed()
    }.getOrNull()

    fun send(ch: Long, text: String): Boolean {
        val s = sess ?: return false
        val b = JSONObject().put("channel_id", ch).put("username", s.name).put("content", text).toString()
        return authed("POST", "/rest/v1/messages", b, mapOf("Prefer" to "return=minimal")).first in 200..299
    }
}
